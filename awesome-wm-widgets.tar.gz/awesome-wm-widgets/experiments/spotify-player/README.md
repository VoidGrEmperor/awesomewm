# Spotify Player 

In progress

![spotify-player](./spotify-player.png)